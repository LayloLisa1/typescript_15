interface UploadedFile {
    originalname: string;
    buffer: Buffer; // or use other properties you need
  }
  import { Controller, Post, UseInterceptors, UploadedFile as UploadedFileDecorator } from '@nestjs/common';
  import { FileInterceptor } from '@nestjs/platform-express';
  
  @Controller('upload')
  export class UploadController {
    @Post()
    @UseInterceptors(FileInterceptor('file'))
    async uploadFile(@UploadedFileDecorator() file: UploadedFile) {
      return {
        originalname: file.originalname,
        // You can access file.buffer or other properties you defined in UploadedFile
      };
    }
  }
    