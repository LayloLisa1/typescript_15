import { IsString, IsNumber, Min } from 'class-validator';

export class CreateProductDto {
  @IsString()
  readonly name: string;

  @IsNumber()
  @Min(0)
  readonly price: number;
}
